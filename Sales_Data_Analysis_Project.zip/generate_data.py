"""
generate_data.py
Generates a synthetic retail sales dataset (sales_data.csv) for the
Sales Data Analysis project. Run this once before eda_analysis.py.
"""

import random
import csv
from datetime import date, timedelta

random.seed(42)

regions = ["North", "South", "East", "West"]
categories = {
    "Electronics": ["Headphones", "Smartphone", "Laptop", "Smartwatch"],
    "Clothing": ["T-Shirt", "Jeans", "Jacket", "Shoes"],
    "Groceries": ["Rice", "Cooking Oil", "Snacks", "Beverages"],
    "Furniture": ["Chair", "Table", "Sofa", "Bookshelf"],
}
price_range = {
    "Electronics": (999, 55000),
    "Clothing": (299, 3999),
    "Groceries": (49, 999),
    "Furniture": (1499, 25000),
}

start_date = date(2025, 1, 1)
rows = []

for i in range(1, 601):
    order_date = start_date + timedelta(days=random.randint(0, 364))
    category = random.choice(list(categories.keys()))
    product = random.choice(categories[category])
    region = random.choice(regions)
    quantity = random.randint(1, 8)
    low, high = price_range[category]
    unit_price = round(random.uniform(low, high), 2)
    revenue = round(quantity * unit_price, 2)
    rows.append({
        "OrderID": i,
        "Date": order_date.isoformat(),
        "Region": region,
        "Category": category,
        "Product": product,
        "Quantity": quantity,
        "UnitPrice": unit_price,
        "Revenue": revenue,
    })

with open("sales_data.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

print(f"Generated {len(rows)} rows -> sales_data.csv")
