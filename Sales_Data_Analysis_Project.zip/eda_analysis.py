"""
eda_analysis.py
Exploratory Data Analysis on a retail Sales dataset using Pandas & Matplotlib.

Project: Sales Data Analysis
Author: Ankit Kumar

What this script does:
1. Loads the sales dataset and inspects its structure (info, describe, nulls).
2. Answers common business questions using groupby/aggregation:
   - Which region generates the most revenue?
   - Which product category sells the most?
   - How does revenue trend across months?
3. Saves 4 charts as PNG images and prints a text summary of insights.
"""

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------------------------------------------------------------
# 1. Load & Inspect Data
# ---------------------------------------------------------------
df = pd.read_csv("sales_data.csv", parse_dates=["Date"])

print("=" * 60)
print("STEP 1: DATA OVERVIEW")
print("=" * 60)
print(f"Shape: {df.shape[0]} rows, {df.shape[1]} columns\n")
print("Data types:")
print(df.dtypes, "\n")
print("Missing values per column:")
print(df.isnull().sum(), "\n")
print("Summary statistics:")
print(df.describe(include="all"))

# ---------------------------------------------------------------
# 2. Revenue by Region
# ---------------------------------------------------------------
revenue_by_region = df.groupby("Region")["Revenue"].sum().sort_values(ascending=False)

plt.figure(figsize=(7, 5))
revenue_by_region.plot(kind="bar", color="#2b6cb0")
plt.title("Total Revenue by Region")
plt.ylabel("Revenue (INR)")
plt.xlabel("Region")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("chart_revenue_by_region.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 3. Category-wise Sales Share
# ---------------------------------------------------------------
category_share = df.groupby("Category")["Revenue"].sum()

plt.figure(figsize=(6, 6))
plt.pie(category_share, labels=category_share.index, autopct="%1.1f%%",
        startangle=90, colors=["#2b6cb0", "#38a169", "#d69e2e", "#c53030"])
plt.title("Revenue Share by Category")
plt.tight_layout()
plt.savefig("chart_category_share.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 4. Monthly Revenue Trend
# ---------------------------------------------------------------
df["Month"] = df["Date"].dt.to_period("M")
monthly_revenue = df.groupby("Month")["Revenue"].sum()

plt.figure(figsize=(9, 5))
monthly_revenue.plot(kind="line", marker="o", color="#2b6cb0")
plt.title("Monthly Revenue Trend (2025)")
plt.ylabel("Revenue (INR)")
plt.xlabel("Month")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("chart_monthly_trend.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 5. Top 5 Best-Selling Products (by Quantity)
# ---------------------------------------------------------------
top_products = df.groupby("Product")["Quantity"].sum().sort_values(ascending=False).head(5)

plt.figure(figsize=(7, 5))
top_products.plot(kind="barh", color="#38a169")
plt.title("Top 5 Products by Quantity Sold")
plt.xlabel("Units Sold")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("chart_top_products.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 6. Print Key Insights
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("STEP 2: KEY INSIGHTS")
print("=" * 60)
print(f"Total Revenue           : Rs. {df['Revenue'].sum():,.2f}")
print(f"Total Orders             : {df.shape[0]}")
print(f"Average Order Value      : Rs. {df['Revenue'].mean():,.2f}")
print(f"Top Region by Revenue    : {revenue_by_region.idxmax()} "
      f"(Rs. {revenue_by_region.max():,.2f})")
print(f"Top Category by Revenue  : {category_share.idxmax()} "
      f"(Rs. {category_share.max():,.2f})")
print(f"Best-Selling Product     : {top_products.idxmax()} "
      f"({top_products.max()} units)")
print(f"Best Month for Sales     : {monthly_revenue.idxmax()} "
      f"(Rs. {monthly_revenue.max():,.2f})")
print("\nCharts saved: chart_revenue_by_region.png, chart_category_share.png,")
print("              chart_monthly_trend.png, chart_top_products.png")
